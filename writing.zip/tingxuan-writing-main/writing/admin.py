from django.contrib import admin

from .models import WritingExam, WritingRecord

admin.site.register(WritingExam)
admin.site.register(WritingRecord)
