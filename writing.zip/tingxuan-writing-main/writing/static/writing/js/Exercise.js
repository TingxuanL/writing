var second = 0;
setInterval(timer, 1000);

var selectStart = selectEnd = -1;
var inputTextArea = document.getElementById("EnglishWriting");

document.getElementById("EnglishWriting").addEventListener('click', event => {
    // console.log("click" + document.getElementById("EnglishWriting").selectionStart) // logs previous location
    // return false;
    // alert("No selection is allowed!");
    selectStart = selectEnd = -1;
    inputTextArea.selectionStart = inputTextArea.selectionEnd;
    // inputTextArea.selectionEnd = inputTextArea.selectionEnd;
    return false;
});

// document.getElementById("EnglishWriting").addEventListener('mousedown', event => {
//     console.log("mousedown" + document.getElementById("EnglishWriting").selectionStart) // logs previous location
//     // return false;
//     // event.preventDefault();
// });

// document.getElementById("EnglishWriting").addEventListener('mouseup', event => {
//     console.log("mouseup" + document.getElementById("EnglishWriting").selectionStart) // logs previous location
//     return false;
// });

document.getElementById("EnglishWriting").addEventListener('select', event => {
    alert("No selection is allowed!");
    selectionRange = getInputSelection(inputTextArea);
    selectStart = selectionRange.start;
    selectEnd = selectionRange.end;
        // alert("No selection is allowed!");
        selectStart = selectEnd = -1;
        inputTextArea.selectionStart = inputTextArea.selectionEnd;
    // event.preventDefault();
    // return false;
});


var record = {"startTime": new Date().getTime(), "sequences": []};

if (localStorage.getItem("second") != null) {
    second = localStorage.getItem("second");
    document.getElementById("timer").innerText = '使用时间：' + second + '秒';
}

function timer() {
    second++;
    document.getElementById("timer").innerText = '使用时间：' + second + '秒';
    document.getElementById("EnglishWriting").focus();
}

function getInputSelection(el) {
    var start = 0, end = 0, normalizedValue, range,
        textInputRange, len, endRange;

    if (typeof el.selectionStart == "number" && typeof el.selectionEnd == "number") {
        start = el.selectionStart;
        end = el.selectionEnd;
    } else {
        range = document.selection.createRange();

        if (range && range.parentElement() == el) {
            len = el.value.length;
            normalizedValue = el.value.replace(/\r\n/g, "\n");

            // Create a working TextRange that lives only in the input
            textInputRange = el.createTextRange();
            textInputRange.moveToBookmark(range.getBookmark());

            // Check if the start and end of the selection are at the very end
            // of the input, since moveStart/moveEnd doesn't return what we want
            // in those cases
            endRange = el.createTextRange();
            endRange.collapse(false);

            if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
                start = end = len;
            } else {
                start = -textInputRange.moveStart("character", -len);
                start += normalizedValue.slice(0, start).split("\n").length - 1;

                if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
                    end = len;
                } else {
                    end = -textInputRange.moveEnd("character", -len);
                    end += normalizedValue.slice(0, end).split("\n").length - 1;
                }
            }
        }
    }

    return {
        start: start,
        end: end
    };
}

function keyboardInput(event) {
    timeNow = new Date();
    positionInfo = getInputSelection(inputTextArea);
    // currentText = document.getElementById("examRecord").value;
    // document.getElementById("examRecord").value = currentText + '|' + positionInfo.start + ',' + event.data + ',' + event.inputType + ',' + timeNow.getTime();
    // console.log(positionInfo);
    
        record["sequences"].push({"selectStart": selectStart,
                                  "selectEnd": selectEnd,
                                  "position": positionInfo.start-1,
                                  "data": event.data,
                                  "inputType": event.inputType,
                                  "time": timeNow.getTime()});
    selectStart = -1;
    selectEnd = -1;
    
    document.getElementById("examRecord").value = JSON.stringify(record);
}

async function replayRecord() {
    second = 0;
    document.getElementById("timer").innerText = '使用时间：' + second + '秒';
    inputTextArea.value = "";
    sequences = record["sequences"];
    startTime = record["startTime"];
    waitTime = startTime;
    for (i=0; i < sequences.length; ++i) {
        r = sequences[i];
        // console.log(r);
        position = r["position"];
        data = r["data"];
        inputType = r["inputType"];
        t_selectStart = r["selectStart"]
        t_selectEnd = r["selectEnd"]
        waitTime = r["time"] - startTime;
        startTime = r["time"];
        await sleep(waitTime);
        switch (inputType) {
            case "insertText":
                currentValue = inputTextArea.value;
                if (t_selectStart == t_selectEnd) {
                    inputTextArea.value = currentValue.slice(0, position) + data + currentValue.slice(position, currentValue.length);
                } else {
                    inputTextArea.value = currentValue.slice(0, t_selectStart) + data + currentValue.slice(t_selectEnd, currentValue.length);
                }
                break;
            case "deleteContentBackward":
            case "deleteContentForward":
                currentValue = inputTextArea.value;
                if (t_selectStart == t_selectEnd) {
                    inputTextArea.value = currentValue.slice(0, position+1) + currentValue.slice(position+2, currentValue.length);
                } else {
                    inputTextArea.value = currentValue.slice(0, t_selectStart) + currentValue.slice(t_selectEnd, currentValue.length);
                }
                break;
        }
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}