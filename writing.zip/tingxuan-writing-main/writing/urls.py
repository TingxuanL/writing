#!/usr/bin/env python
# coding=utf-8
from django.urls import path

from . import views

app_name = 'writing'
urlpatterns = [
    # ex: /
    path('', views.index, name='index'),
    path('<int:exam_id>/', views.exam, name='exam'),
    path('record/<int:exam_id>/', views.record_exam, name='record_exam'),
]
