#!/usr/bin/env python
# coding=utf-8
from django.db import models
from django.utils.translation import gettext as _

from django.conf import settings

# Create your models here.

class WritingExam(models.Model):
    title = models.CharField(
        verbose_name=_('exam title'),
        help_text=_('Title. Do not exceed 255 characters.'),
        max_length=255
    )
    description = models.TextField(
        verbose_name=_('description')
    )

    def __str__(self):
        return self.title

class WritingRecord(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name=_('user'),
        blank=True,
        null=True,
        on_delete=models.SET_NULL
    )
    exam = models.ForeignKey(
        WritingExam,
        verbose_name=_('exam'),
        on_delete=models.CASCADE
    )
    record = models.TextField(
        verbose_name=_('record')
    )
    datetime = models.DateTimeField(
        verbose_name=_('datetime'),
    )

    def __str__(self) -> str:
        return str(self.exam.title) + str(self.user) + ' ' + str(self.datetime)
