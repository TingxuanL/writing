from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.template import RequestContext
from django.utils import timezone
from django.urls import reverse
from django.contrib.auth.decorators import login_required

from .models import WritingExam, WritingRecord


@login_required
def index(request):
    return HttpResponse("Thank you for participating!")

@login_required
def exam(request, exam_id):
    exam = get_object_or_404(WritingExam, pk=exam_id)
    context = {
        'exam': exam,
    }
    return render(request, 'writing/exam.html', context)

@login_required
def record_exam(request, exam_id):
    exam = get_object_or_404(WritingExam, pk=exam_id)
    record = request.POST['examRecord']
    exam_record = WritingRecord(user=request.user, exam=exam, record=record, datetime=timezone.now())
    exam_record.save()
    return HttpResponseRedirect(reverse('writing:index'))
